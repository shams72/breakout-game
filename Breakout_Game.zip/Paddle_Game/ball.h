#ifndef BALL_H
#define BALL_H



#include<QGraphicsRectItem>

class Ball:public QObject,public QGraphicsRectItem
{
    Q_OBJECT
public:
    Ball();
    double getCenterX();

public slots:
    void move();

private:
    double xVelocity;
    double yVelocity;

    void reverseVelocityIfOutOfBounds();
    void handlePaddleCollision();
    void handleBlockCollision();



};

#endif // BALL_H
