#include "ball.h"
#include "QBrush"
#include"QTimer"
#include"Game.h"
#include"paddle.h"
#include"block.h"
#include<QList>
#include<qapplication.h>
extern Game* game;


Ball::Ball()
{
    setRect(0,0,50,50);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::red);
    setBrush(brush);

    xVelocity=0;
    yVelocity=-5;

    QTimer* timer= new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));
    timer->start(15);



}

double Ball::getCenterX(){
    return x()+rect().width()/2;
}

void Ball::move(){
    reverseVelocityIfOutOfBounds();
    handleBlockCollision();
    handlePaddleCollision();
    moveBy(xVelocity,yVelocity);

}

void Ball::reverseVelocityIfOutOfBounds(){
    double screenW=game->width();
    double screenH=game->height();

    if(mapToScene(rect().topLeft()).x()<=0){
        xVelocity=-1*xVelocity;
    }
    else if(mapToScene(rect().topRight()).x()>=screenW){
        xVelocity=-1*xVelocity;
    }
    else if(mapToScene(rect().topLeft()).y()<=0){
        yVelocity=-1*yVelocity;
    }
}

void Ball::handlePaddleCollision()
{
    QList<QGraphicsItem*> cItems=collidingItems();
    for(int i=0;i<cItems.size();i++){
        Paddle* paddle=dynamic_cast<Paddle*>(cItems[i]);
        if(paddle){
            yVelocity=-1*yVelocity;

            double ballx=getCenterX();
            double paddlex=paddle->getCenterX();

            double dvx= ballx-paddlex;
            xVelocity=(xVelocity+dvx)/15;

            return;
        }
    }

}

void Ball::handleBlockCollision()
{
    QList<QGraphicsItem*>cItems=collidingItems();
    for(int i=0;i<cItems.size();i++){
        Block* block=dynamic_cast<Block*>(cItems[i]);
        if(block){
            double Ballx=pos().x();
            double Bally=pos().y();
            double blockx=block->pos().x();
            double blocky=block->pos().y();

            if(Bally>blocky&&yVelocity<0){
                yVelocity=-1*yVelocity;
            }


            if(Bally<blocky&&yVelocity>0){
                yVelocity=-1*yVelocity;
            }


            if(Ballx>blocky&&xVelocity<0){
                xVelocity=-1*xVelocity;
            }


            if(Ballx<blocky&&yVelocity>0){
                xVelocity=-1*xVelocity;
            }

            game->scene->removeItem(block);
            delete block;



        }
    }

}



