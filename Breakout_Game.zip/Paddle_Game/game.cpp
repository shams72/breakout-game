#include "game.h"
#include"ball.h""
#include"paddle.h"
#include"block.h"

Game::Game()
{
    scene=new QGraphicsScene(0,0,400,400);
    setScene(scene);
    setMouseTracking(true);
}

void Game::start(){

    Ball* ball=new Ball();
    ball->setPos(200,500);
    scene->addItem(ball);

    Paddle* paddle= new Paddle();
    paddle->setPos(150,575);
    scene->addItem(paddle);
    paddle->grabMouse();

    createBlock();




}

void Game::createblockcol(double x)
{
    for(int i=0;i<=5;i++){
        Block* block=new Block();
        block->setPos(x,i*52);
        scene->addItem(block);
    }


}

void Game::createBlock()
{

    for(int i=0;i<=7;i++){
        createblockcol(i*52);
    }


}


