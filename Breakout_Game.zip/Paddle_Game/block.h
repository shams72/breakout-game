#ifndef BLOCK_H
#define BLOCK_H

#include <QGraphicsRectItem>


class Block:public QGraphicsRectItem
{
public:
    Block();
};

#endif // BLOCK_H
